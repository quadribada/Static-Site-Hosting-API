(() => {
  document.getElementById('current-year').innerHTML = new Date().getFullYear()
})()
